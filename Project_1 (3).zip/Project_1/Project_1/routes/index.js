// Names: Mishaal.G and Casey.P
// Date: Nov.12.2024
// Class: Web and Script Programming
// Purpose: This is responsible for defining the route for the homepage

var express = require('express'); // Imports express for module creation
var router = express.Router(); // New router instance creation 
const passport = require('passport')
let DB = require('../config/db')
let userModel = require('../models/user')
let User = userModel.User;

// Render the main page
// Render the main page
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express',
    displayName:req.user ? req.user.displayName:''
   }); 
});

// get and post router of login.ejs
router.get('/login',function(req,res,next){
  if(!req.user)
  {
    res.render('Auth/login',{
      title:'Login',
      message:req.flash('loginMessage'),
      displayName:req.user ? req.user.displayName:''
    })
  }
  else{
    return res.redirect('/');
  }
})
router.post('/login',function(req,res,next){
  passport.authenticate('local',(err,user,info)=>{
    if(err)
    {
      return next(err);
    }
    if(!user)
    {
      req.flash('loginMessage','AuthenticationError');
      return res.redirect('/login')
    }
    req.login(user,(err)=>{
      if(err)
      {
        return next(err)
      }
      return res.redirect('/');
    })
  })(req,res,next)
})

// get and post router of register.ejs
router.get('/register',function(req,res,next){
  if(!req.user)
  {
    res.render('Auth/register',
      {
        title:'Register',
        message:req.flash('registerMessage'),
        displayName: req.user ? req.user.displayName:''
      }
    )
  }
  else
  {
    return res.redirect('/')
  }
})
router.post('/register',function(req,res,next){
  let newUser = new User({
    username: req.body.username,
    password:req.body.password,
    email:req.body.email,
    displayName:req.body.displayName
  })
  User.register(newUser, req.body.password,(err)=>{
    if(err){
      console.log("Error:Inserting the new user");
      if(err.name=="UserExistsError")
      {
          req.flash('registerMessage',
            'Registration Error: User already exists');
      }
      return res.render('auth/register',
        {
          title:'Register',
          message:req.flash('registerMessage'),
          displayName: req.user ? req.user.displayName:''
        })
    }
    else{
      return passport.authenticate('local')(req,res,()=>{
        res.redirect('/')
      })
    }
  })
})
router.get('/logout',function(req,res,next){
  req.logout(function(err){
    if(err)
    {
      return next(err)
    }
  })
  res.redirect('/')
})

// Exporets the router 
module.exports = router;

// End of program